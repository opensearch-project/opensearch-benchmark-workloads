"""
This script converts images in ABO dataset https://amazon-berkeley-objects.s3.amazonaws.com/index.html into base64 encoded binary.
Then store the image description and image binary in abo_documents.json file that used for running multimodal search workload.
"""

import base64
import os
import json
import pandas as pd
from glob import glob

def read_item_data(json_files):
    """
    Read multiple JSON files and combine item_id and item_name
    Returns dict with item_id as key and item_name as value
    """
    item_descriptions = {}
    for json_file in json_files:
        print(f"Processing {json_file}")
        try:
            with open(json_file, 'r') as f:

                for line in f:
                    try:
                        item = json.loads(line)
                        item_descriptions[item['main_image_id']] = item['item_name'][0]['value']
                    except Exception as e:
                        with open('item_not_loaded.txt', 'a') as fi:
                            fi.write(line)
                        pass
        except Exception as e:
            print(f"Error reading {json_file}: {str(e)}")

    return item_descriptions


def image_to_base64_json(image_dir, image_path, description, main_image_id, cumulative_id):
    """Convert image to base64 and create JSON object with cumulative ID"""
    try:
        absolute_image_path = os.path.join(image_dir, image_path)
        if not os.path.exists(absolute_image_path):
            raise FileNotFoundError(f"Image file not found: {absolute_image_path}")

        file_extension = absolute_image_path.lower().split('.')[-1]
        if file_extension not in ['jpg', 'jpeg', 'png']:
            raise ValueError("Only JPG and PNG files are supported")

        with open(absolute_image_path, 'rb') as image_file:
            base64_string = base64.b64encode(image_file.read()).decode('utf-8')

            json_data = {
                "_id": cumulative_id,
                "main_image_id": main_image_id,
                "image_description": description,
                "image_binary": base64_string,
                "image_path": image_path
            }

            return json_data

    except Exception as e:
        print(f"Error processing {image_path}: {str(e)}")
        return None


def process_images(item_descriptions, image_dir, images_df, output_file):
    """
    Process images based on item_id mapping

    Args:
    item_descriptions: Dict of item_id: item_name
    images_df: DataFrame containing image paths
    output_file: Path to output JSON Lines file
    """
    cumulative_id = 1
    image_path = None

    with open(output_file, 'w') as f:
        try:
            for main_image_id, description in item_descriptions.items():
                # Find matching image path in DataFrame
                matching_rows = images_df[images_df['image_id'] == main_image_id]

                if matching_rows.empty:
                    print(f"No image found for item_id: {main_image_id}")
                    continue

                image_path = matching_rows.iloc[0]['path']  # Get first matching path

                json_data = image_to_base64_json(image_dir, image_path, description, main_image_id, cumulative_id)
                if json_data:
                    f.write(json.dumps(json_data) + '\n')
                    cumulative_id += 1

        except Exception as e:
            print(f"Error processing {image_path}: {str(e)}")

def main():
    # Path to JSON files containing item data
    json_files = glob('/path/to/abo/abo-listings/listings/metadata/*.json')

    # Path to images.csv file
    images_csv = '/path/to/abo/abo-images-small/images/metadata/images.csv'

    # Path to directory that contains all images
    image_dir = '/path/to/abo/abo-images-small/images/small/'

    # Output file path
    output_file = 'abo_documents.json'

    try:
        # Read item descriptions from JSON files
        print("Reading item descriptions from JSON files...")
        item_descriptions = read_item_data(json_files)
        print(f"Found {len(item_descriptions)} items")

        # Read images.csv
        print("Reading images.csv...")
        images_df = pd.read_csv(images_csv)

        # Process images and create JSON Lines file
        print("Processing images...")
        process_images(item_descriptions, image_dir, images_df, output_file)

        print(f"\nAll processing complete. Output saved to {output_file}")

    except Exception as e:
        print(f"Error in main execution: {str(e)}")


if __name__ == "__main__":
    main()
